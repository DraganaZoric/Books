import AdapterLuxon from '@mui/lab/AdapterLuxon';
import LocalizationProvider from '@mui/lab/LocalizationProvider';

import './App.css';
import BookDetails from './BookDetails';
import AllBooksPage from './AllBooksPage';
import { BrowserRouter as Router, Link as RouterLink, 
  Switch, Route, useHistory, Redirect, 
  useLocation} from 'react-router-dom';

import { Button } from '@mui/material';

import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';

import { addBook } from './accessHooks';
import BookDetailsPage from './BookDetailsPage';
import BookSearchPage from './BookSearchPage';

import { useAuth, ProvideAuth} from './useAuth';
import { Formik } from 'formik';
import { TextField } from '@mui/material';
import BookSearchByAuthor from './BookSearchByAuthor';
import { useState } from 'react';


import PasswordChecklist from 'react-password-checklist';


const AuthButton = () => {
  const [login, error, signin, signout] = useAuth();
  const history = useHistory();
  if(login){
      return <Button variant="contained" onClick={() => {
          signout( () => history.push("/"));            
      }}>Sign out</Button>
  }else{
      return <span><Button variant="contained" component={RouterLink} to="/register">Register</Button>
     <Button variant="contained" component={RouterLink} to="/login">Log in</Button></span>
  }
}


const PrivateRoute = ({children, ...rest}) => {
  const [login, error, signin, signout] = useAuth();
  return (
      <Route
          {...rest}
          render={({location}) => {
              if(login){
                  return children;
              }else{
                  return <Redirect
                      to={{pathname: "/login", state: {from: location}}}
                  />
              }
          }}
          />
  ); 
}


const LoginBox = () => {
  const history = useHistory();
  const location = useLocation();
  const [login, error, signin, signout] = useAuth();
  
  let {from} = location.state || { from : { pathname: "/"}};
  return <div className="loginBox">
      <h3>Login Forma</h3>
      <Formik
          initialValues={{username: "", password: ""}}
          onSubmit={(values, { setSubmitting }) => {
              signin(values.username, values.password, () => {
                  setSubmitting(false);
              }, () => {
                  history.replace(from);
              });
          }}
      >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
            setFieldValue,
            setFieldTouched,
            validateField,
            isSubmitting
          }) => (
              <form onSubmit={handleSubmit}>
                  <TextField
                    fullWidth 
                    variant="outlined" 
                    name="username" 
                    value={values.username} 
                    label="Korisničko ime" 
                    onChange={handleChange}
                  /><br/>
                  <TextField 
                    fullWidth
                    variant="outlined" 
                    name="password" 
                    value={values.password} 
                    label="Lozinka" 
                    onChange={handleChange}
                    type="password"                    
                  /><br/>
                  <Button 
                    fullWidth 
                    variant="contained" 
                    type="submit" 
                    disabled={isSubmitting}
                  >
                    Log in
                  </Button>
                  <div>{(error) ? error : ""}</div>
              </form>
          )}
      </Formik>
  </div>
}


const RegisterBox = () => {
    const history = useHistory();
    const location = useLocation();
    const [register, error, signin, signout] = useAuth();

    
    
    let {from} = location.state || { from : { pathname: "/"}};
    return <div className="registerBox">
        <h3>Register Forma</h3>
        
        <Formik
            initialValues={{username: "", password: ""}}
            onSubmit={(values, { setSubmitting }) => {
                register(values.username, values.password, () => {
                    setSubmitting(false);
                }, () => {
                    history.replace(from);
                });
            }}
        >
            {({
              values,
              errors,
              touched,
              handleChange,
              handleBlur,
              handleSubmit,
              setFieldValue,
              setFieldTouched,
              validateField,
              isSubmitting
            }) => (
                <form onSubmit={handleSubmit}>
                    <TextField
                     /*  fullWidth 
                      variant="outlined" 
                      name="username" 
                      value={values.username} 
                      label="Korisničko ime" 
                      onChange={handleChange} */
                      component={Validacija}
                    /><br/>
                   {/*  <TextField 
                      fullWidth
                      variant="outlined" 
                      name="password" 
                      value={values.password} 
                      label="Lozinka" 
                      onChange={handleChange}
                      type="password"                    
                    /><br/>
                     <TextField 
                      fullWidth
                      variant="outlined" 
                      name="password_conformation" 
                      value={values.password_confirmation}
                      label="Ponovljena lozinka" 
                      onChange={handleChange}
                      type="password" 
                      
                                 
                     /><br/> */}

                   {/*  <Button 
                      fullWidth 
                      variant="contained" 
                      type="submit" 
                      disabled={isSubmitting}
                    >
                      Register
                    </Button> */}
                    <div>{(error) ? error : ""}</div>
                </form>
            )}
        </Formik>
    </div>
  }

  const Validacija = () => {
    const [password, setPassword] = useState("")
    const [passwordAgain, setPasswordAgain] = useState("")
    const [username, setUsername] = useState("")
    return (
      <form>
        <label>Username:</label>
        <input type="username" onChange={e => setUsername(e.target.value)}/>
        <br/>
        <label>Password:</label>
        <input type="password" onChange={e => setPassword(e.target.value)}/>
        <label>Password Again:</label>
        <input type="password" onChange={e => setPasswordAgain(e.target.value)}/>
  
        <PasswordChecklist
          rules={["minLength","specialChar","number","capital","match"]}
          minLength={12}
          value={password}
          valueAgain={passwordAgain}
          messages={{
            minLength: "Lozinka je kraca od 12 karaktera.",
            specialChar: "Lozinka mora da sadrzi specijalni karakter.",
            number: "Lozinka mora da sadrzi broj.",
            capital: "Lozinka mora da sadrzi veliko slovo.",
            match: "Lozinke se ne podudaraju.",
          }}
        />

<Button 
                      fullWidth 
                      variant="contained" 
                      type="submit" 
                      
                    >
                      Register
                    </Button>

      </form>
    )
  }



const AddBookPage = () => {
  const [login] = useAuth();
  return <BookDetails startingMode="create" action={(book) => addBook(book, login)}/>
}



function App() {
  return (
    <LocalizationProvider dateAdapter={AdapterLuxon}>
      <ProvideAuth>
        <Router>
          <div className="main">
        
            <nav className="mainNav">
              <Button component={RouterLink} to="/allbooks" variant="contained" sx={{marginRight: "10px"}}>
                  Sve knjige
              </Button>
              <Button component={RouterLink} to="/searchbooks" variant="contained">
                  Pretraga
              </Button>
              <Button component={RouterLink} to="/searchByAuthor" variant="contained">
                  Autor
              </Button>
              <Button component={RouterLink} to="/searchbooks" variant="contained">
                  Zanr
              </Button>
              <span style={{flexGrow: 1}}/>
              <AuthButton></AuthButton>
            </nav>
            <div className="mainContent">
              <Switch>
              <Route path="/register">
                  <RegisterBox/>
                </Route>
                <Route path="/login">
                  <LoginBox/>
                </Route>
                <PrivateRoute path="/allbooks">
                  <AllBooksPage/>
                </PrivateRoute>
                <PrivateRoute path="/searchbooks">
                  <BookSearchPage/>
                </PrivateRoute>
                <PrivateRoute path="/book/new">
                  <AddBookPage/>
                </PrivateRoute>
                <PrivateRoute path="/searchByAuthor">
                  <BookSearchByAuthor/>
                </PrivateRoute>
                <PrivateRoute path="/book/:cid/:operation">
                  <BookDetailsPage/>
                </PrivateRoute>
                <Route path="/">
                  <h1 >Magic Books</h1>
                
 
     
                 
                </Route>
              </Switch>
            </div>
          </div>
        </Router>
      </ProvideAuth>
    </LocalizationProvider>
  );
}

export default App;







  





