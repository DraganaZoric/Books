import React, {useState, useContext, createContext} from 'react';

const authContext = createContext();

export const ProvideAuth = ({children}) => {
    const auth = useProvideAuth();
    return <authContext.Provider value={auth}>
        {children}
    </authContext.Provider>
}

export const useAuth = () => {
    return useContext(authContext);
}

const useProvideAuth = () => {
    const [login, setLogin] = useState(null);
    const [error, setError] = useState("");
    const signin = (username, password, failCallback = () => {}, okCallback = () => {}) => {
        fetch("http://localhost:3081/app/login", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({username: username, password: password})
        }).then(response => response.json())
        .then(data => {
            if(data.status != "ok"){
                setLogin(null);
                setError(data.body);
                failCallback();    
            }else{
                setLogin(data.body);
                setError(""); 
                okCallback();
            }
        })
        .catch(err => {
            setLogin(null);
            setError(err);
            failCallback();
        });
    }
    const signout = (cb = () => {}) => {
        setLogin(null);
        setError("");
        cb();
    }

    return [login, error, signin, signout];
}

//odavde cekiranje passworda
/* function checkPassword(){
    let password = document.getElementById("password").value;
    let password_conformation = document.getElementById("password_conformation").value;
    console.log(" Password:", password,'\n',"Confirm Password:",password_conformation);
    let message = document.getElementById("message");

    if(password.length != 0){
        if(password == password_conformation){
            message.textContent = "Passwords match";
            message.style.backgroundColor = "#1dcd59";
        }
        else{
            message.textContent = "Password don't match";
            message.style.backgroundColor = "#ff4d4d";
        }
    }
    else{
        alert("Password can't be empty!");
        message.textContent = "";
    }
} */