#Kako pokrenuti

U ovom direktorijumu izvršiti (prvi put kada pokrećete) `npm install` a zatim `npm start`  Vodite računa da ovo sluša na portu 3081. 